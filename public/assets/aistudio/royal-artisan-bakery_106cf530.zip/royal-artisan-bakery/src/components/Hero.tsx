import { lazy, Suspense, useMemo } from 'react'
import { motion, useReducedMotion } from 'framer-motion'
import { ArrowRight, MapPin } from 'lucide-react'
import { business } from '../config/business'
import { hasWebGL, useIsMobile } from '../hooks/useEnv'
import ProductArt from './ProductArt'

const BakeryScene = lazy(() => import('../scenes/BakeryScene'))

function StaticFallback() {
  return (
    <div className="absolute right-0 top-24 hidden h-[70%] w-1/2 grid-cols-2 gap-4 p-8 md:grid">
      {(['croissant', 'bread', 'pastry', 'cheesecake'] as const).map((k) => (
        <ProductArt key={k} kind={k} className="h-full w-full rounded-3xl" />
      ))}
    </div>
  )
}

export default function Hero() {
  const mobile = useIsMobile()
  const reduced = !!useReducedMotion()
  const webgl = useMemo(() => hasWebGL(), [])
  return (
    <section id="home" className="relative min-h-screen overflow-hidden bg-espresso text-cream">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_70%_40%,rgba(183,123,67,0.28),transparent_60%)]" />
      <div className="pointer-events-none absolute inset-0" aria-hidden="true">
        {webgl ? (
          <Suspense fallback={null}><BakeryScene mobile={mobile} reduced={reduced} /></Suspense>
        ) : (
          <StaticFallback />
        )}
      </div>
      <div className="relative z-10 mx-auto flex min-h-screen max-w-7xl flex-col justify-end px-5 pb-16 pt-32 sm:px-8 md:justify-center md:pb-0">
        <motion.p className="eyebrow" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }}>Artisan Bakery · Pastry · Café · Westminster</motion.p>
        <motion.h1
          className="mt-4 max-w-2xl text-5xl font-semibold leading-[1.02] sm:text-6xl lg:text-8xl"
          initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5, duration: 0.9 }}
        >
          Crafted with Passion. <span className="text-copper">Baked to Perfection.</span>
        </motion.h1>
        <motion.p className="mt-6 max-w-md text-base leading-relaxed text-cream/75 sm:text-lg" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.8 }}>
          Breads, pastries and cakes made with care, with British, European and Mediterranean influences, at {business.address.line1}, Westminster.
        </motion.p>
        <motion.div className="mt-8 flex flex-wrap gap-3" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 1 }}>
          <a href="#menu" className="btn btn-copper">Explore Our Menu <ArrowRight size={16} /></a>
          <a href="#visit" className="btn btn-outline-light"><MapPin size={16} /> Visit Our Bakery</a>
        </motion.div>
      </div>
    </section>
  )
}
