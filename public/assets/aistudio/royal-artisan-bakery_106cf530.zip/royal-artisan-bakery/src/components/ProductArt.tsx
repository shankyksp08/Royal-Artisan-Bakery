import type { ArtKind } from '../config/business'

/** Original vector illustrations used wherever a real photo is not supplied. */
export default function ProductArt({ kind, className = '' }: { kind: ArtKind; className?: string }) {
  const C = { crust: '#B77B43', dark: '#38291F', deep: '#211914', cream: '#F3EBDD', light: '#E2C79B' }
  const shape = (() => {
    switch (kind) {
      case 'croissant':
        return (
          <g>
            {[-3, -2, -1, 0, 1, 2, 3].map((i) => (
              <ellipse key={i} cx={100 + i * 20} cy={110 - (3 - Math.abs(i)) * 6 + Math.abs(i) * 4} rx={20 - Math.abs(i) * 2} ry={30 - Math.abs(i) * 3} fill={i % 2 ? C.crust : '#C98A4B'} transform={`rotate(${i * 14} ${100 + i * 20} 110)`} />
            ))}
          </g>
        )
      case 'pastry':
      case 'savoury':
        return (
          <g>
            <rect x="35" y="72" width="130" height="56" rx="26" fill={kind === 'pastry' ? C.crust : '#C98A4B'} />
            {[60, 85, 110, 135].map((x) => <path key={x} d={`M${x} 76 q8 24 0 48`} stroke={C.light} strokeWidth="3" fill="none" />)}
            {kind === 'pastry' && <rect x="42" y="92" width="116" height="10" rx="5" fill={C.deep} opacity=".7" />}
          </g>
        )
      case 'danish':
        return (
          <g>
            <circle cx="100" cy="100" r="58" fill={C.crust} />
            <circle cx="100" cy="100" r="40" fill="#C98A4B" />
            <circle cx="100" cy="100" r="22" fill={C.light} />
            {[0, 72, 144, 216, 288].map((a) => <ellipse key={a} cx="100" cy="100" rx="5" ry="12" fill={C.cream} transform={`rotate(${a} 100 100) translate(0 -8)`} />)}
          </g>
        )
      case 'bread':
        return (
          <g>
            <ellipse cx="100" cy="112" rx="68" ry="44" fill={C.crust} />
            {[-26, 0, 26].map((x) => <path key={x} d={`M${100 + x - 10} 92 q10 -8 20 0`} stroke={C.light} strokeWidth="6" strokeLinecap="round" fill="none" />)}
          </g>
        )
      case 'baguette':
        return (
          <g transform="rotate(-28 100 100)">
            <rect x="14" y="80" width="172" height="40" rx="20" fill={C.crust} />
            {[40, 74, 108, 142].map((x) => <path key={x} d={`M${x} 90 l14 20`} stroke={C.light} strokeWidth="5" strokeLinecap="round" />)}
          </g>
        )
      case 'brownie':
        return (
          <g>
            <rect x="48" y="62" width="104" height="80" rx="10" fill={C.deep} />
            <rect x="48" y="62" width="104" height="22" rx="10" fill={C.dark} />
            {[[70, 100], [100, 112], [128, 98], [86, 124]].map(([x, y]) => <circle key={`${x}${y}`} cx={x} cy={y} r="4" fill={C.crust} opacity=".6" />)}
          </g>
        )
      case 'cheesecake':
      case 'cake':
        return (
          <g>
            <path d="M40 150 L160 150 L160 96 L40 96 Z" fill={kind === 'cake' ? C.crust : C.light} />
            <rect x="40" y="118" width="120" height="8" fill={C.cream} />
            <rect x="40" y="96" width="120" height="14" rx="7" fill={C.cream} />
            {[70, 100, 130].map((x) => <circle key={x} cx={x} cy="88" r="9" fill={kind === 'cake' ? C.crust : '#8C3B33'} />)}
          </g>
        )
      case 'sandwich':
        return (
          <g>
            <path d="M30 130 L100 58 L170 130 Z" fill={C.crust} />
            <path d="M44 130 L100 74 L156 130 Z" fill={C.cream} />
            <path d="M58 130 L100 90 L142 130 Z" fill="#7E8F5A" />
            <rect x="30" y="130" width="140" height="16" rx="8" fill={C.crust} />
          </g>
        )
      case 'pizza':
        return (
          <g>
            <path d="M100 160 L40 60 Q100 30 160 60 Z" fill={C.light} />
            <path d="M40 60 Q100 30 160 60" stroke={C.crust} strokeWidth="14" fill="none" strokeLinecap="round" />
            {[[90, 80], [112, 96], [98, 116]].map(([x, y]) => <circle key={`${x}${y}`} cx={x} cy={y} r="8" fill="#8C3B33" />)}
          </g>
        )
      default:
        return (
          <g>
            <path d="M60 80 h80 v38 a40 32 0 0 1 -80 0 Z" fill={C.cream} />
            <path d="M140 92 h16 a14 14 0 0 1 0 28 h-18" stroke={C.cream} strokeWidth="7" fill="none" />
            <rect x="66" y="84" width="68" height="10" rx="5" fill={C.crust} />
          </g>
        )
    }
  })()
  return (
    <svg viewBox="0 0 200 200" role="img" aria-hidden="true" className={className} preserveAspectRatio="xMidYMid slice">
      <defs>
        <radialGradient id={`g-${kind}`} cx="50%" cy="40%" r="75%">
          <stop offset="0%" stopColor="#3a2c22" />
          <stop offset="100%" stopColor="#211914" />
        </radialGradient>
      </defs>
      <rect width="200" height="200" fill={`url(#g-${kind})`} />
      <ellipse cx="100" cy="162" rx="62" ry="8" fill="#000" opacity=".3" />
      {shape}
    </svg>
  )
}
