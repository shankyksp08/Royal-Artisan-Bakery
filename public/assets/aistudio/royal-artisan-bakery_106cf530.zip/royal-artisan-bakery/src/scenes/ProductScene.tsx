import { useRef } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { ContactShadows, Environment, Lightformer, OrbitControls } from '@react-three/drei'
import type { Group } from 'three'
import { shapeMap, type ShapeKey } from './Shapes'

function Model({ item }: { item: ShapeKey }) {
  const ref = useRef<Group>(null)
  const t = useRef(0)
  useFrame((_, dt) => {
    t.current = Math.min(1, t.current + dt * 2.2)
    ref.current?.scale.setScalar(1.7 * (1 - Math.pow(1 - t.current, 3)))
  })
  const Shape = shapeMap[item]
  return <group ref={ref} key={item}><Shape /></group>
}

export default function ProductScene({ item, mobile, reduced }: { item: ShapeKey; mobile: boolean; reduced: boolean }) {
  return (
    <Canvas dpr={mobile ? [1, 1.5] : [1, 2]} camera={{ position: [0, 1.2, 6], fov: 36 }} gl={{ antialias: !mobile }} aria-label="Interactive 3D bakery product">
      <ambientLight intensity={0.4} />
      <directionalLight position={[3, 5, 4]} intensity={2.2} color="#ffe2bd" />
      <Model key={item} item={item} />
      <ContactShadows position={[0, -1.3, 0]} opacity={0.5} scale={9} blur={2.4} far={3} />
      <Environment resolution={256}>
        <Lightformer form="rect" intensity={2} position={[0, 5, -3]} scale={[10, 4, 1]} color="#fff3df" />
        <Lightformer form="rect" intensity={1} position={[-5, 1, 2]} scale={[3, 6, 1]} color="#B77B43" />
      </Environment>
      <OrbitControls enablePan={false} enableZoom={false} autoRotate={!reduced} autoRotateSpeed={1.6} minPolarAngle={Math.PI / 3} maxPolarAngle={Math.PI / 1.9} />
    </Canvas>
  )
}
