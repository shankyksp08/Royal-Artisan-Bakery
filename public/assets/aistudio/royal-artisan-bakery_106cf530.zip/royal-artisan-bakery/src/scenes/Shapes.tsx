import type { ReactNode } from 'react'

const crust = { roughness: 0.55, metalness: 0.02 }

export function Croissant() {
  return (
    <group>
      {[-3, -2, -1, 0, 1, 2, 3].map((i) => {
        const s = 1 - Math.abs(i) * 0.13
        return (
          <mesh key={i} position={[i * 0.34, -Math.pow(i, 2) * 0.035 + 0.1, 0]} rotation={[0, 0, i * 0.28]} scale={[0.3 * s, 0.44 * s, 0.34 * s]} castShadow>
            <sphereGeometry args={[1, 32, 24]} />
            <meshStandardMaterial color={i % 2 ? '#B77B43' : '#C98A4B'} {...crust} />
          </mesh>
        )
      })}
    </group>
  )
}

export function Bread() {
  return (
    <group>
      <mesh scale={[1.15, 0.62, 0.8]} castShadow>
        <sphereGeometry args={[1, 48, 32]} />
        <meshStandardMaterial color="#B77B43" {...crust} />
      </mesh>
      {[-0.4, 0, 0.4].map((x) => (
        <mesh key={x} position={[x, 0.5, 0]} rotation={[0, 0, -0.5]} scale={[1, 1, 1]}>
          <capsuleGeometry args={[0.035, 0.42, 4, 10]} />
          <meshStandardMaterial color="#F3EBDD" roughness={0.8} />
        </mesh>
      ))}
    </group>
  )
}

export function PainAuChocolat() {
  return (
    <group rotation={[0, 0, Math.PI / 2]}>
      <mesh scale={[1, 1, 0.85]} castShadow>
        <capsuleGeometry args={[0.38, 0.9, 12, 24]} />
        <meshStandardMaterial color="#C98A4B" {...crust} />
      </mesh>
      {[-0.25, 0, 0.25].map((y) => (
        <mesh key={y} position={[0, y, 0]} scale={[1, 1, 0.85]}>
          <torusGeometry args={[0.385, 0.02, 8, 32]} />
          <meshStandardMaterial color="#8a5a2d" roughness={0.7} />
        </mesh>
      ))}
      <mesh position={[0, 0.82, 0]}>
        <cylinderGeometry args={[0.22, 0.22, 0.12, 20]} />
        <meshStandardMaterial color="#211914" roughness={0.35} />
      </mesh>
    </group>
  )
}

export function Cake() {
  const layers: ReactNode[] = [0, 1].map((i) => (
    <group key={i} position={[0, i * 0.4, 0]}>
      <mesh castShadow>
        <cylinderGeometry args={[0.8, 0.8, 0.3, 48]} />
        <meshStandardMaterial color="#C98A4B" roughness={0.7} />
      </mesh>
      <mesh position={[0, 0.2, 0]}>
        <cylinderGeometry args={[0.82, 0.82, 0.1, 48]} />
        <meshStandardMaterial color="#F3EBDD" roughness={0.5} />
      </mesh>
    </group>
  ))
  return (
    <group>
      {layers}
      {[[0.3, 0.15], [-0.2, 0.3], [0, -0.35]].map(([x, z], i) => (
        <mesh key={i} position={[x, 0.98, z]} scale={[1, 0.9, 1]}>
          <sphereGeometry args={[0.13, 20, 16]} />
          <meshStandardMaterial color="#8C2F39" roughness={0.4} />
        </mesh>
      ))}
      <mesh position={[0, 0.86, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[0.55, 0.025, 8, 48]} />
        <meshStandardMaterial color="#B77B43" metalness={0.5} roughness={0.3} />
      </mesh>
    </group>
  )
}

export const shapeMap = {
  croissant: Croissant,
  bread: Bread,
  pain: PainAuChocolat,
  cake: Cake,
} as const
export type ShapeKey = keyof typeof shapeMap
