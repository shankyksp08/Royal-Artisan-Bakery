import { useEffect, useRef } from 'react'
import { Canvas } from '@react-three/fiber'
import { ContactShadows, Environment, Lightformer } from '@react-three/drei'
import FloatingProducts from './FloatingProducts'

export default function BakeryScene({ mobile, reduced }: { mobile: boolean; reduced: boolean }) {
  const pointer = useRef({ x: 0, y: 0 })
  useEffect(() => {
    const on = (e: PointerEvent) => {
      pointer.current.x = (e.clientX / window.innerWidth) * 2 - 1
      pointer.current.y = (e.clientY / window.innerHeight) * 2 - 1
    }
    window.addEventListener('pointermove', on, { passive: true })
    return () => window.removeEventListener('pointermove', on)
  }, [])

  return (
    <Canvas
      shadows={!mobile}
      dpr={mobile ? [1, 1.5] : [1, 2]}
      camera={{ position: [0, 0, 7.5], fov: 38 }}
      gl={{ antialias: !mobile, powerPreference: 'high-performance' }}
      frameloop={reduced ? 'demand' : 'always'}
      aria-hidden="true"
    >
      <ambientLight intensity={0.35} />
      <directionalLight position={[4, 6, 5]} intensity={2.2} color="#ffe2bd" castShadow={!mobile} shadow-mapSize={[1024, 1024]} />
      <pointLight position={[-5, -2, 3]} intensity={18} color="#B77B43" />
      <FloatingProducts pointer={pointer} mobile={mobile} reduced={reduced} />
      {!mobile && <ContactShadows position={[0, -2.4, 0]} opacity={0.4} scale={14} blur={2.6} far={4} color="#000" />}
      <Environment resolution={256}>
        <Lightformer form="rect" intensity={2.2} position={[0, 5, -4]} scale={[10, 4, 1]} color="#fff3df" />
        <Lightformer form="rect" intensity={1.2} position={[-5, 1, 2]} scale={[3, 6, 1]} color="#B77B43" />
        <Lightformer form="ring" intensity={1} position={[5, 2, 3]} scale={3} color="#F3EBDD" />
      </Environment>
    </Canvas>
  )
}
