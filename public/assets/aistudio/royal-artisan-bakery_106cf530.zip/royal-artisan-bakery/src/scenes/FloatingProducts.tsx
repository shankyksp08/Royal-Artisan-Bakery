import { useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { Float } from '@react-three/drei'
import type { Group } from 'three'
import { Bread, Cake, Croissant, PainAuChocolat } from './Shapes'

interface Props { pointer: React.MutableRefObject<{ x: number; y: number }>; mobile: boolean; reduced: boolean }

export default function FloatingProducts({ pointer, mobile, reduced }: Props) {
  const root = useRef<Group>(null)
  const intro = useRef(0)
  useFrame((state, dt) => {
    const g = root.current
    if (!g) return
    intro.current = Math.min(1, intro.current + dt * 0.9)
    const e = 1 - Math.pow(1 - intro.current, 3)
    const base = mobile ? 0.62 : 1
    g.scale.setScalar(base * e)
    const k = reduced ? 0 : 1
    g.rotation.y += ((pointer.current.x * 0.35 * k) - g.rotation.y) * 0.05
    g.rotation.x += ((-pointer.current.y * 0.15 * k) - g.rotation.x) * 0.05
    state.camera.position.x += (pointer.current.x * 0.6 * k - state.camera.position.x) * 0.04
    state.camera.lookAt(0, 0, 0)
  })
  const f = reduced ? 0 : 1
  return (
    <group ref={root} position={mobile ? [0, 1.5, 0] : [1.9, 0, 0]}>
      <Float speed={1.4 * f} rotationIntensity={0.5 * f} floatIntensity={0.9 * f}>
        <group position={[-0.5, 0.9, 0.4]} rotation={[0.4, 0.5, 0.1]} scale={1.15}><Croissant /></group>
      </Float>
      <Float speed={1.1 * f} rotationIntensity={0.4 * f} floatIntensity={0.7 * f}>
        <group position={[1.9, -0.7, -0.6]} rotation={[0.2, -0.5, 0]} scale={1.1}><Bread /></group>
      </Float>
      <Float speed={1.6 * f} rotationIntensity={0.6 * f} floatIntensity={0.8 * f}>
        <group position={[-1.5, -1.3, 0.8]} rotation={[0.3, 0.4, 0.4]} scale={0.95}><PainAuChocolat /></group>
      </Float>
      <Float speed={1.2 * f} rotationIntensity={0.3 * f} floatIntensity={0.6 * f}>
        <group position={[1.4, 1.5, -1.4]} rotation={[0.35, 0.2, 0]} scale={0.9}><Cake /></group>
      </Float>
    </group>
  )
}
