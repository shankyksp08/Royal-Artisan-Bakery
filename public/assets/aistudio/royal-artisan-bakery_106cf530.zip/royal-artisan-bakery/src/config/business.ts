/**
 * CENTRAL BUSINESS CONFIGURATION
 * Edit everything about the business here: contact details, opening hours,
 * products, gallery images, social links.
 * Anything set to null / empty is hidden or replaced with a safe fallback.
 */

export type ArtKind =
  | 'croissant' | 'pastry' | 'danish' | 'bread' | 'baguette' | 'brownie'
  | 'cheesecake' | 'cake' | 'savoury' | 'sandwich' | 'pizza' | 'coffee'

export interface Product {
  id: string
  name: string
  description: string
  art: ArtKind
  /** Optional real photo, e.g. '/images/croissant.jpg' (place the file in /public/images) */
  image?: string
}

export const business = {
  name: 'Royal Artisan Bakery',
  tagline: 'Crafted with Passion. Baked to Perfection.',
  address: {
    line1: '84-86 Petty France',
    city: 'London',
    postcode: 'SW1H 9EA',
    country: 'United Kingdom',
  },
  phoneDisplay: '+44 20 7799 4999',
  phoneHref: 'tel:+442077994999',
  email: 'info@quartergroup.co.uk',
  website: 'https://quartergroup.co.uk/royal-artisan-bakery/',
  mapsUrl: 'https://maps.app.goo.gl/5wZfNEbmGApMNnpLA',
  mapsEmbed:
    'https://www.google.com/maps?q=Royal+Artisan+Bakery,+84-86+Petty+France,+London+SW1H+9EA&output=embed',

  /**
   * OPENING HOURS: not verified, so left empty. Confirm on Google Maps / the
   * official website, then fill in, e.g.:
   * [{ day: 'Monday – Friday', hours: '07:30 – 17:00' }]
   */
  openingHours: [] as { day: string; hours: string }[],

  /** Only add links you have verified. Empty string = hidden. */
  social: { instagram: '', facebook: '' },
  /** WhatsApp button appears only if filled, e.g. '447000000000' (no + or spaces). */
  whatsapp: '',
  /** Link used by the reviews call-to-action. */
  reviewsUrl: 'https://maps.app.goo.gl/5wZfNEbmGApMNnpLA',
}

export const products: Product[] = [
  { id: 'croissant', name: 'Butter Croissants', art: 'croissant', description: 'Flaky, golden laminated pastry, baked for a crisp shell and soft layers.' },
  { id: 'pain-au-chocolat', name: 'Pain au Chocolat', art: 'pastry', description: 'Classic viennoiserie wrapped around rich dark chocolate.' },
  { id: 'almond-danish', name: 'Almond Danish', art: 'danish', description: 'A tender pastry finished with almond for a sweet, nutty bite.' },
  { id: 'artisan-bread', name: 'Artisan Bread', art: 'bread', description: 'Hand-crafted loaves with a crackling crust and open crumb.' },
  { id: 'baguettes', name: 'Baguettes', art: 'baguette', description: 'Long, crisp-crusted baguettes in the French tradition.' },
  { id: 'brownies', name: 'Brownies', art: 'brownie', description: 'Dense, fudgy chocolate squares for the sweet-toothed.' },
  { id: 'raspberry-cheesecake', name: 'Raspberry Cheesecake', art: 'cheesecake', description: 'Creamy cheesecake brightened with fresh raspberry.' },
  { id: 'biscoff-cheesecake', name: 'Biscoff Cheesecake', art: 'cheesecake', description: 'Smooth cheesecake with caramelised Biscoff flavour.' },
  { id: 'carrot-cake', name: 'Carrot Cake', art: 'cake', description: 'Spiced, moist sponge layered with cream frosting.' },
  { id: 'savoury-pastries', name: 'Savoury Pastries', art: 'savoury', description: 'Golden pastries with savoury fillings for a lunchtime bite.' },
  { id: 'sandwiches', name: 'Sandwiches', art: 'sandwich', description: 'Freshly assembled sandwiches on bakery bread.' },
  { id: 'pizza-slices', name: 'Pizza Slices', art: 'pizza', description: 'Generous slices, ideal for a quick grab-and-go lunch.' },
]

export interface GalleryItem { label: string; art: ArtKind; image?: string; alt: string }

/** Add real photos by setting `image: '/images/your-file.jpg'` */
export const gallery: GalleryItem[] = [
  { label: 'Pastries', art: 'croissant', alt: 'Freshly baked pastries' },
  { label: 'Cakes', art: 'cheesecake', alt: 'Cakes and desserts' },
  { label: 'Bread', art: 'bread', alt: 'Artisan bread loaves' },
  { label: 'Coffee', art: 'coffee', alt: 'Coffee and specialty drinks' },
  { label: 'Savoury', art: 'savoury', alt: 'Savoury pastries' },
  { label: 'Sandwiches', art: 'sandwich', alt: 'Bakery sandwiches' },
]

export const navLinks = [
  { label: 'Home', href: '#home' },
  { label: 'About', href: '#about' },
  { label: 'Our Menu', href: '#menu' },
  { label: 'Gallery', href: '#gallery' },
  { label: 'Contact', href: '#contact' },
  { label: 'Visit Us', href: '#visit' },
]
