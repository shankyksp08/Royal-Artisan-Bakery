import { lazy, Suspense, useMemo, useState } from 'react'
import { useReducedMotion } from 'framer-motion'
import Reveal from '../components/Reveal'
import ProductArt from '../components/ProductArt'
import { hasWebGL, useIsMobile } from '../hooks/useEnv'
import type { ShapeKey } from '../scenes/Shapes'

const ProductScene = lazy(() => import('../scenes/ProductScene'))
const items: { key: ShapeKey; label: string; note: string; art: 'croissant' | 'bread' | 'pastry' | 'cake' }[] = [
  { key: 'croissant', label: 'Croissant', note: 'Layered, golden and buttery.', art: 'croissant' },
  { key: 'bread', label: 'Artisan Bread', note: 'Scored, crusty and hand-shaped.', art: 'bread' },
  { key: 'pain', label: 'Pain au Chocolat', note: 'Flaky pastry around dark chocolate.', art: 'pastry' },
  { key: 'cake', label: 'Layered Cake', note: 'Cream, sponge and fresh berries.', art: 'cake' },
]

export default function Showcase() {
  const [sel, setSel] = useState<ShapeKey>('croissant')
  const mobile = useIsMobile()
  const reduced = !!useReducedMotion()
  const webgl = useMemo(() => hasWebGL(), [])
  const cur = items.find((i) => i.key === sel)!
  return (
    <section className="bg-espresso text-cream">
      <div className="section">
        <Reveal className="mb-10 text-center">
          <p className="eyebrow">3D Showcase</p>
          <h2 className="mt-3 text-4xl font-semibold md:text-6xl">Turn it. Explore it.</h2>
          <p className="mt-3 text-cream/70">Drag to rotate. Illustrative 3D models, not product photography.</p>
        </Reveal>
        <div className="mx-auto h-[360px] max-w-3xl overflow-hidden rounded-3xl bg-[radial-gradient(circle_at_50%_40%,#3a2c22,#211914)] sm:h-[460px]">
          {webgl ? (
            <Suspense fallback={<p className="grid h-full place-items-center text-sm text-cream/60">Loading 3D…</p>}>
              <ProductScene item={sel} mobile={mobile} reduced={reduced} />
            </Suspense>
          ) : (
            <ProductArt kind={cur.art} className="h-full w-full" />
          )}
        </div>
        <p className="mt-4 text-center text-cream/80">{cur.note}</p>
        <div className="mt-6 flex flex-wrap justify-center gap-3" role="tablist" aria-label="Choose a product">
          {items.map((i) => (
            <button key={i.key} role="tab" aria-selected={sel === i.key} onClick={() => setSel(i.key)} className={`btn ${sel === i.key ? 'btn-copper' : 'btn-outline-light'}`}>{i.label}</button>
          ))}
        </div>
      </div>
    </section>
  )
}
