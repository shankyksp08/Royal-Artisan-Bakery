import Reveal from '../components/Reveal'
import { business } from '../config/business'

export default function FinalCTA() {
  return (
    <section className="bg-espresso text-cream">
      <Reveal className="mx-auto max-w-4xl px-5 py-24 text-center sm:px-8">
        <h2 className="text-5xl font-semibold md:text-7xl">Your Next Favourite <span className="text-copper">Treat Awaits.</span></h2>
        <div className="mt-10 flex flex-wrap justify-center gap-3">
          <a href="#menu" className="btn btn-copper">Explore Our Menu</a>
          <a href={business.mapsUrl} target="_blank" rel="noopener noreferrer" className="btn btn-outline-light">Get Directions</a>
          <a href="#contact" className="btn btn-outline-light">Contact Us</a>
        </div>
      </Reveal>
    </section>
  )
}
