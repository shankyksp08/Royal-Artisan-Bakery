# Royal Artisan Bakery – 3D Marketing Website

React + Vite + TypeScript + Three.js (React Three Fiber / Drei) + Tailwind CSS + Framer Motion + Lucide.

## Run locally
```bash
npm install
npm run dev        # http://localhost:5173
npm run build      # type-check + production build into /dist
npm run preview
```
Requires Node 18+.

## Where to edit
| What | Where |
|---|---|
| Address, phone, email, map links, opening hours, social links, WhatsApp | `src/config/business.ts` |
| Menu items (names, descriptions, photos) | `products` in `src/config/business.ts` |
| Gallery photos | `gallery` in `src/config/business.ts` |
| Colours | `tailwind.config.js` (espresso, cream, copper, ink) |
| Page title, description, Open Graph, structured data | `index.html` |
| 3D objects | `src/scenes/Shapes.tsx` (procedural models, no downloads needed) |

### Adding real photos
Put files in `public/images/` (e.g. `croissant.jpg`) and set `image: '/images/croissant.jpg'` on the product or gallery item. Until then, original vector illustrations are shown. Only use photos you own or have permission to use.

### Opening hours
Not verified, so `openingHours` is empty and the site points visitors to Google Maps. Fill it in once confirmed.

### Contact form
Validates name, email and message, then opens the visitor's email app addressed to `info@quartergroup.co.uk` (no backend needed). For direct delivery, connect a service such as Formspree and replace the `mailto` line in `src/components/Contact.tsx`.

### Open Graph image
Add `og:image` (1200×630 JPG/PNG, absolute URL) in `index.html` once you have a photo.

## Google AI Studio
Download/export this folder as a ZIP, upload it into your AI Studio / Build workspace, then run `npm install` and `npm run dev` (or ask AI Studio to run the project). If it requests a different entry point, keep `index.html` and `src/main.tsx`.

## Deploy to Vercel
1. Push the folder to GitHub.
2. In Vercel: **Add New → Project → import the repo**.
3. Framework: **Vite**. Build command `npm run build`, output `dist`. Deploy.
(CLI alternative: `npm i -g vercel && vercel --prod`.)

## Notes
- 3D falls back to static illustrations if WebGL is unsupported, and animation is reduced for `prefers-reduced-motion`.
- No ordering, payment, or booking is implemented; this is a marketing and enquiry site.
